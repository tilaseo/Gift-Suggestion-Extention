// Trong popupHandler.js
document.addEventListener("DOMContentLoaded", function() {
  var suggestButton = document.getElementById("suggestButton");

  if (suggestButton) {
    suggestButton.addEventListener("click", function() {
      suggestGift();
    });
  }
});
