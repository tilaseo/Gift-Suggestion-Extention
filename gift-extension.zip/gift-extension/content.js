// content.js

// Hàm xử lý cú pháp và trả về gợi ý quà tặng
function getGiftSuggestionsFromSyntax(syntax) {
  syntax = syntax.toLowerCase();
  var who, when;

  // Phân tích cú pháp để lấy thông tin về đối tượng và dịp
  if (syntax.includes("+")) {
    var parts = syntax.split("+");
    who = parts[0].trim();
    when = parts[1].trim();
  } else {
    // Nếu không có dấu "+" trong cú pháp, giả sử toàn bộ là đối tượng
    who = syntax.trim();
    when = "anytime";
  }

  // Tạo gợi ý quà tặng dựa trên đối tượng và dịp
  var suggestions = [];

  // Đối tượng là sếp và dịp cuối năm
  if (who === "sếp" && when === "cuối năm") {
    suggestions.push("Bộ sưu tập bút cao cấp", "Sổ da handmade", "Quà lưu niệm tinh tế");
  }

  // Thêm các điều kiện khác tùy thuộc vào yêu cầu của bạn

  return suggestions;
}

// Lắng nghe sự kiện khi có thay đổi trên trang và thực hiện xử lý
chrome.runtime.onMessage.addListener(function (request, sender, sendResponse) {
  if (request.action === "suggestGifts") {
    var suggestions = getGiftSuggestionsFromSyntax(request.syntax);
    sendResponse({ suggestions: suggestions });
  }
});
