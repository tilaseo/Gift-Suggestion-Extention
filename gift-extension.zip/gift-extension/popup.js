// Trong popup.js
function suggestGift() {
  var input = document.getElementById("giftInput").value;
  // Thực hiện xử lý cú pháp và hiển thị gợi ý quà tặng tương ứng
  var suggestions = getGiftSuggestions(input);
  displaySuggestions(suggestions);
}

// Trong popup.js
function getGiftSuggestions(input) {
  // Xử lý cú pháp và trả về một mảng gợi ý quà tặng
  var who = input.split('+')[0].trim().toLowerCase();
  var when = input.split('+')[1].trim().toLowerCase();

  // Chuyển đổi Unicode về chuỗi thường để so sánh
  who = who.normalize("NFD").replace(/[\u0300-\u036f]/g, "");
  when = when.normalize("NFD").replace(/[\u0300-\u036f]/g, "");

  // Gợi ý quà tặng dựa trên đối tượng và dịp
  if (who === "nhan vien" && when === "ngay 8/3") {
    return ["Bó hoa tươi", "Thẻ quà tặng", "Máy pha cà phê"];
  } else if (who === "khach hang" && when === "ngay tet") {
    return ["Bộ quà cao cấp", "Sổ tay da thật", "Rượu vang đặc biệt"];
  } else if (who === "sep" && when === "thang chuc") {
    return ["Bút ký cao cấp", "Bức tranh nghệ thuật", "Voucher nghỉ dưỡng"];
  } else if (who === "nguoi yeu" && when === "le tinh nhan") {
    return ["Hộp quà đầy ý nghĩa", "Đồ trang sức", "Chuyến du lịch ngắn ngày"];
  } else if (who === "gia dinh" && when === "ngay cuoi") {
    return ["Bộ nồi chảo mới", "Khung ảnh gia đình", "Bộ chén đĩa sang trọng"];
  } else if (who === "ban be" && when === "ngay 20/10") {
    return ["Cuốn sách mới", "Quần áo thời trang", "Bảo trì spa"];
  } else {
    return ["Không có gợi ý cho cú pháp này"];
  }
}


function displaySuggestions(suggestions) {
  var suggestionsDiv = document.getElementById("suggestions");
  suggestionsDiv.innerHTML = "<p>Suggested Gifts:</p>";
  for (var i = 0; i < suggestions.length; i++) {
    suggestionsDiv.innerHTML += "<p>" + suggestions[i] + "</p>";
  }
}

// Trong popupHandler.js
document.addEventListener("DOMContentLoaded", function() {
  var suggestButton = document.getElementById("suggestButton");

  if (suggestButton) {
    suggestButton.addEventListener("click", function() {
      suggestGift();
    });
  }
});
